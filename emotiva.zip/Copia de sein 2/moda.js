let openModal = document.getElementById('openModal');
let modalDescarga = document.getElementById('modal');
let closeModal = document.getElementById('close');
let superModal = document.getElementById('suModal');
let cerrarModal = document.getElementById('cerrarModal');

// abrir modal
openModal.onclick = function (){
    modalDescarga.style.visibility = 'visible'
    superModal.style.visibility = 'visible'
    closeModal.style.visibility = 'visible';
}

// cerrar modal
closeModal.onclick = function (){
    modalDescarga.style.visibility = 'hidden'
    superModal.style.visibility = 'hidden'
    closeModal.style.visibility = 'hidden';
}
// cerrar ventana
superModal.click = function (){
    modalDescarga.style.visibility = 'hidden'
    superModal.style.visibility = 'visible'
    closeModal.style.visibility = 'hidden';
    if (superModal.onclick == true) {
        superModal.style.visibility = 'visible'
        modalDescarga.style.visibility ='visible'
        closeModal.style.visibility = 'visible';
    } else {
        superModal.style.visibility = 'hidden'
        modalDescarga.style.visibility ='hidden'
        closeModal.style.visibility = 'hidden';
    }
}

/*modalDescarga.onclick = function (){
    modalDescarga.style.visibility = '';
}*/

//  validacion de formulario //
const email = document.getElementById("mail");
const Nombre = document.getElementById('name');
const Telefono = document.getElementById('subject');

email.addEventListener("input", function (event) {
  if (email.valueMissing.typeMismatch) {
    email.setCustomValidity("Ingresa direccion de correo");
  } else {
    email.setCustomValidity("");
  }
});

///Prueba
$(document).ready(function(){

    $('#btn-primary').click(function(){

        var errores = '';

        // Validado Nombre ==============================
        if( $('#name').val() == '' ){
            errores += '<p>Escriba un nombre</p>';
            $('#name').css("border-bottom-color", "#F14B4B")
        } else{
            $('#name').css("border-bottom-color", "#d1d1d1")
        }

        // Validado Correo ==============================
        if( $('#mail').val() == '' ){
            errores += '<p>Ingrese un correo</p>';
            $('#mail').css("border-bottom-color", "#F14B4B")
        } else{
            $('#mail').css("border-bottom-color", "#d1d1d1")
        }
        // Validado Telefono ==============================
        if( $('#subject').val() == '' ){
            errores += '<p>Ingrese un correo</p>';
            $('#subject').css("border-bottom-color", "#F14B4B")
        } else{
            $('#subject').css("border-bottom-color", "#d1d1d1")
        }

        /*/ Validado Mensaje ==============================
        if( $('#mensaje').val() == '' ){
            errores += '<p>Escriba un mensaje</p>';
            $('#mensaje').css("border-bottom-color", "#F14B4B")
        } else{
            $('#mensaje').css("border-bottom-color", "#d1d1d1")
        }*/

        // ENVIANDO MENSAJE ============================
        if( errores == '' == false){
            var mensajeModal = '<div class="modal_wrap">'+
                                    '<div class="mensaje_modal">'+
                                        '<h3>Errores encontrados</h3>'+
                                        errores+
                                        '<span id="btnClose">Cerrar</span>'+
                                    '</div>'+
                                '</div>'

            $('body').append(mensajeModal);
        }

        // CERRANDO MODAL ==============================
        $('#btnClose').click(function(){
            $('.modal_wrap').remove();
        });
    });

});