let openModal = document.getElementById('openModal');
let modalDescarga = document.getElementById('modal');
let closeModal = document.getElementById('close');
// abrir modal

openModal.onclick = function (){
    modalDescarga.style.visibility = 'visible';
}
// cerrar modal
closeModal.onclick = function (){
    modalDescarga.style.visibility = 'hidden';
}
// cerrar ventana
modalDescarga.onclick = function (){
    modalDescarga.style.visibility = 'visible';
}

